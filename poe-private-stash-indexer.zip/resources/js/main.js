document.addEventListener("DOMContentLoaded",function(){
    initSwitchCategoryLogic();
    initButtonLogic();
    initSortLogic();
    initGetJewels();
});
